package com.example.irmelinompelimo_harjoitustyo;

import android.content.Context;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import androidx.appcompat.widget.Toolbar;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    GridView gridView;

    static final String[] TUOTTEET = new String[] {
            "Pipo", "Kaulahuivi", "Lapaset", "Hanskat", "Villapaita", "Villasukat" };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = (GridView) findViewById(R.id.gridView1);

        gridView.setAdapter(new ImageAdapter(this, TUOTTEET));

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                Toast.makeText(
                        getApplicationContext(),
                        ((TextView) v.findViewById(R.id.grid_item_label))
                                .getText(), Toast.LENGTH_SHORT).show();


            }
        });

        // Find the toolbar view inside the activity layout
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        // Sets the Toolbar to act as the ActionBar for this Activity window.
        // Make sure the toolbar exists in the activity and is not null
        setSupportActionBar(toolbar);

        //Näillä yritetään poistaa projektin nimi yläpalkista
        //Testaa!
        //getSupportActionBar().setTitle(null);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        //getSupportActionBar().setTitle("");
        //toolbar.setSubtitle("");
        //toolbar.setSubtitle(null);
        //toolbar.setTitle("");
        //toolbar.setTitle(null);

        fadeIn(toolbar);

        /*toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(),"your icon was clicked",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            }
        });*/
    }
    public class ImageAdapter extends BaseAdapter {
        private Context context;
        private final String[] mobileValues;

        public ImageAdapter(Context context, String[] mobileValues) {
            this.context = context;
            this.mobileValues = mobileValues;
        }

        //---returns an ImageView view---
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            View gridView;

            if (convertView == null) {

                gridView = new View(context);

                // get layout from mobile.xml
                gridView = inflater.inflate(R.layout.mobile, null);

                // set value into textview
                TextView textView = (TextView) gridView
                        .findViewById(R.id.grid_item_label);
                textView.setText(mobileValues[position]);

                // set image based on selected text
                ImageView imageView = (ImageView) gridView
                        .findViewById(R.id.grid_item_image);

                String mobile = mobileValues[position];
                if (mobile.equals("Kaulahuivi")) {
                    imageView.setImageResource(R.drawable.ic_huivi);
                    goToShop();
                } else if (mobile.equals("Lapaset")) {
                    imageView.setImageResource(R.drawable.ic_lapaset);
                    goToShop();
                } else if (mobile.equals("Hanskat")) {
                    imageView.setImageResource(R.drawable.ic_hanskat);
                } else if (mobile.equals("Villapaita")) {
                    imageView.setImageResource(R.drawable.ic_paita);
                    goToShop();
                } else if (mobile.equals("Villasukat")) {
                    imageView.setImageResource(R.drawable.ic_sukat);
                    goToShop();
                } else {
                    imageView.setImageResource(R.drawable.ic_pipo);
                    goToShop();
                }

            } else {
                gridView = (View) convertView;
            }


            return gridView;
        }

        //---returns the number of images---
        @Override
        public int getCount() {
            return mobileValues.length;
        }

        //---returns the item---
        @Override
        public Object getItem(int position) {
            return null;
        }

        //---returns the ID of an item---
        @Override
        public long getItemId(int position) {
            return 0;
        }

    }

    // Menu icons are inflated just as they were with actionbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    // Respond to menu item clicks
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.miCart:
                startActivity(new Intent(getApplicationContext(), OstoskoriActivity.class));
                return true;
            case R.id.homeButton:
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                return true;
            case R.id.miLogIn:
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                return true;
            case R.id.action_login:
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                return true;
            case R.id.action_delivery:
                startActivity(new Intent(getApplicationContext(), DeliveryActivity.class));
                return true;
            case R.id.action_tuotetieto:
                startActivity(new Intent(getApplicationContext(), TuotetietoActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void goToShop()      //Kun käyttäjä painaa jotain tuotetta, siirrytään tänne
    {
        //Intent sendData = new Intent(this, OstoskoriActivity.class);
        //GridView myGrid = (GridView) findViewById(R.id.gridView1);
        //String gridText = myGrid.getTooltipText().toString();                       //Tästä ei hajuakaan....
        //sendData.putExtra(GRID_MESSAGE, gridText);
        //startActivity(sendData);
    }
    private void fadeIn(View view) {
        // Create an AlphaAnimation variable
        // 0.0f makes the view invisible
        // 1.0f makes the view fully visible
        AlphaAnimation anim = new AlphaAnimation(0.0f, 1.0f);
        // Set out long you want the animation to be. * Measured in milliseconds *
        // 1000 milliseconds = 1 second
        anim.setDuration(1500);
        // Start the animation on our passed in view
        view.startAnimation(anim);
        /*  After the animation is complete we want to make sure we set the visibility of the view
            to VISIBLE. Otherwise it will go back to being INVISIBLE due to our previous lines
            that set the view to INVISIBLE */
        view.setVisibility(View.VISIBLE);
    }

    /*
    Lisää XML:ssä toolbariin (ei toiminut):
            app:navigationIcon="@drawable/ic_name"
        android:onClick="goHomeActivity"

        public void goHomeActivity (View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }*/
}

