package com.example.irmelinompelimo_harjoitustyo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class OstoskoriActivity extends AppCompatActivity {
    GridView shoppingList;
    static final String[] OSTETUT_TUOTTEET = new String[]{
            "  Kaulahuivi 1x Harmaa\n\n24,99€", "  Lapaset 1x Harmaa\n\n9,95€"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        //String gridText = intent.getStringExtra(MainActivity.GRID_MESSAGE);     //Tarkoitus saada tänne GridView alkusivulta
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ostoskori);
        shoppingList = (GridView) findViewById(R.id.ostoslista);

        shoppingList.setAdapter(new OstoskoriActivity.ShopAdapter(this, OSTETUT_TUOTTEET));

        shoppingList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                Toast.makeText(
                        getApplicationContext(),
                        ((TextView) v.findViewById(R.id.grid_item_shoppings))
                                .getText(), Toast.LENGTH_SHORT).show();


            }
        });

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
    }



    public class ShopAdapter extends BaseAdapter {
        private Context context;
        private final String[] shoppingValues;

        public ShopAdapter(Context context, String[] shopValue) {
            this.context = context;
            this.shoppingValues = shopValue;
        }

        @Override
        public int getCount() {
            return shoppingValues.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        //---returns an ImageView view---
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            View shoppingList;

            if (convertView == null) {

                shoppingList = new View(context);

                // get layout from mobile.xml
                shoppingList = inflater.inflate(R.layout.ostoskori_main, null);

                // set value into textview
                TextView textView = (TextView) shoppingList
                        .findViewById(R.id.grid_item_shoppings);
                textView.setText(shoppingValues[position]);

                // set image based on selected text
                ImageView imageView = (ImageView) shoppingList
                        .findViewById(R.id.grid_item_productImage);

                String mobileShopping = shoppingValues[position];
                if (mobileShopping.equals("  Kaulahuivi 1x Harmaa\n\n24,99€")) {
                    imageView.setImageResource(R.drawable.ic_huivi);

                } else if (mobileShopping.equals("  Lapaset 1x Harmaa\n\n9,95€")) {
                    imageView.setImageResource(R.drawable.ic_lapaset);

                } else if (mobileShopping.equals("Hanskat")) {
                    imageView.setImageResource(R.drawable.ic_hanskat);
                } else if (mobileShopping.equals("Villapaita")) {
                    imageView.setImageResource(R.drawable.ic_paita);

                } else if (mobileShopping.equals("Villasukat")) {
                    imageView.setImageResource(R.drawable.ic_sukat);

                } else {
                    imageView.setImageResource(R.drawable.ic_pipo);

                }

            } else {
                shoppingList = (View) convertView;
            }


            return shoppingList;
        }
    }






        @Override
        public boolean onCreateOptionsMenu (Menu menu){
            // Inflate the menu; this adds items to the action bar if it is present.
            getMenuInflater().inflate(R.menu.menu_main, menu);
            return true;
        }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.miCart:
                startActivity(new Intent(getApplicationContext(), OstoskoriActivity.class));
                return true;
            case R.id.homeButton:
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                return true;
            case R.id.miLogIn:
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                return true;
            case R.id.action_login:
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                return true;
            case R.id.action_delivery:
                startActivity(new Intent(getApplicationContext(), DeliveryActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
