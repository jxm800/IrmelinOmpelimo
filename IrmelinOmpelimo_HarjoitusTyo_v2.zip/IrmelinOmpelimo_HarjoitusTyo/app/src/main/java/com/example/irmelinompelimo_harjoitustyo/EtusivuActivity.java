package com.example.irmelinompelimo_harjoitustyo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EtusivuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_etusivu);
    }
}
