package com.example.irmelinompelimo_harjoitustyo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

public class OstoskoriActivity extends AppCompatActivity {
    GridView shoppingList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Intent intent = getIntent();
        String gridText = intent.getStringExtra(MainActivity.GRID_MESSAGE);     //Tarkoitus saada tänne GridView alkusivulta
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ostoskori);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        shoppingList = findViewById(R.id.ostoslista);
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.miCart:
                startActivity(new Intent(getApplicationContext(), OstoskoriActivity.class));
                return true;
            case R.id.homeButton:
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                return true;
            case R.id.action_settings:
                Toast.makeText(
                        getApplicationContext(),
                        "You selected Settings",
                        Toast.LENGTH_SHORT)
                        .show();
                return true;
            case R.id.miLogIn:
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                return true;
            case R.id.action_login:
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}